import React, { useEffect } from "react";
import { Grid, Paper, Typography, Divider, Button } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import france from "./asset/france.svg";
import india from "./asset/india.png";
import "./App.css";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    margin: 20,
  },
  imgSize: {
    height: 500,
    width: 500,
  },
}));

function App() {
  const classes = useStyles();
  return (
    <div>
      <Grid
        container
        direction='row'
        justify='space-around'
        alignItems='center'>
        <Typography variant='h1' id='slide-right'>
          Rafale Delivery
        </Typography>
      </Grid>
      <Grid
        container
        direction='row'
        justify='space-around'
        alignItems='center'>
        <Grid item>
          <img src={france} className={classes.imgSize}></img>
        </Grid>
        <Grid item>
          <img src={india} className={classes.imgSize}></img>
        </Grid>
      </Grid>
      <Grid
        container
        direction='row'
        justify='space-around'
        alignItems='center'>
        <Button variant='contained' size='large'>
          Launch Rafale
        </Button>
      </Grid>
      <Grid
        container
        direction='row'
        justify='space-around'
        alignItems='center'>
        <Typography variant='h1'>5</Typography>
        <Typography variant='h1'>0</Typography>
      </Grid>
    </div>
  );
}

export default App;
